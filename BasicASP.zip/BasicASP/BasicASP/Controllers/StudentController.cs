﻿using BasicASP.Data;
using BasicASP.Models;
using Microsoft.AspNetCore.Mvc;

namespace BasicASP.Controllers
{
    public class StudentController : Controller
    {
        private readonly ApplicationDBContext _db;
        public StudentController(ApplicationDBContext db)
        {
            _db = db;
        }
        public IActionResult Index()
        {
            /*Student s1 = new Student();
            s1.Id=1;
            s1.Name = "Porcha";
            s1.Score = 200;
            
            var s2 = new Student();
            s2.Id = 2;
            s2.Name = "Cha";
            s2.Score = 80;
            Student s3 = new();
            s3.Id = 3;
            s3.Name = "Mee";
            s3.Score = 20;

            List<Student> allStudent = new List<Student>();
            allStudent.Add(s1);
            allStudent.Add(s2);
            allStudent.Add(s3);
            return View(allStudent); */
            IEnumerable<Student> allStudent = _db.Students;
                return View(allStudent);
        }
        //Default เป็น get method เพราะถ้าเป็นpostต้องรับ parameter
        public IActionResult Create()
        {
            return View();
        } 
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(Student obj)
        {
            //ตรวจสอบข้อมูลแล้วว่าถูกตาม model กำหนด
        if(ModelState.IsValid) {
                _db.Students.Add(obj);
                _db.SaveChanges();
                return RedirectToAction("Index");
            }
        return View(obj);
        }
        //รับการแก้ไข
        public IActionResult Edit(int? id)
        {
            if(id==null || id == 0)
            {
                return NotFound();
            }
           var obj =  _db.Students.Find(id);
            if(obj==null)
            {
                return NotFound();
            }
            return View(obj);
        }
        //แก้ไขล่าสุด
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit (Student obj)
        {
            //ตรวจสอบข้อมูลแล้วว่าถูกตาม model กำหนด
            if (ModelState.IsValid)
            {
                _db.Students.Update(obj);
                _db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(obj);
        }
        public IActionResult Delete(int? id)
        {
            if (id == null || id == 0)
            {
                return NotFound();
            }
            //เจอข้อมูลไหม
            var obj = _db.Students.Find(id);
            if (obj == null)
            {
                return NotFound();
            }
           _db.Students.Remove(obj);
            _db.SaveChanges();
            return RedirectToAction("Index");
        }
    }


}
