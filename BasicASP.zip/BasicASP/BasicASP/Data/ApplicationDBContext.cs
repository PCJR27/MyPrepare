﻿using BasicASP.Models;
using Microsoft.EntityFrameworkCore;

namespace BasicASP.Data
{
   //สืบทอดคุณสมบัติจาก DbContext
    public class ApplicationDBContext:DbContext
    {
        public ApplicationDBContext(DbContextOptions<ApplicationDBContext> options) :base(options)
        {

        }
        // เป็นตัวแทนตารางที่เก็บข้อมูลของนักเรียน 
        //จะถูกนำไปสร้างเป็นตาราง Student โดยหากจะอ้างใช้ต้องใช้ชื่อ Students
        //เป็นคำสั่งที่เมื่อมีการเพิ่มการเชื่อมต่อโดย connection String เรียบร้อยแล้ว
        //จะมาอ่านตัวนี้และทำการสร้างฐานข้อมูลที่มีรูปแบบเหมือนกับ Model Student ที่เราออกแบบนั่นเอง
        public DbSet<Student> Students { get; set; }
    }
}
