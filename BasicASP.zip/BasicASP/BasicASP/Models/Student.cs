﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace BasicASP.Models
{
    //ออกแบบพื้นที่เก็บข้อมูล
     // ชื่อโมเดล ชื่อตาราง
    public class Student
    {
        // ชื่อ property ชื่อ column
        // ให้เป็นรูปแบบkey สร้างมาไม่ให้ซ้ำ
        [Key]
        public int Id { get; set; }
        [Required(ErrorMessage ="กรุณาป้อนชื่อนักเรียน")]
        //ห้ามว่างต้องระบุทุกครั้ง
        [DisplayName("ขื่อนักเรียน")]
        public string Name { get; set; }
        [DisplayName("คะแนนสอบ")]
        [Range(0,100,ErrorMessage ="กรุณาป้อนคะแนนสอบในช่วง 0-100")]
        public int Score { get; set; }
    }
}
