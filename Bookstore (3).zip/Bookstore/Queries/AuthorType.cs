﻿using Bookstore.Services;
using Bookstore.ViewModels;

namespace Bookstore.Queries
{
    public class AuthorType :ObjectType<AuthorViewModel>
    {
        protected override void Configure(IObjectTypeDescriptor<AuthorViewModel> descriptor)
        {
            descriptor.Field(author => author.AuthorId);
            descriptor.Field(author => author.Name);
            descriptor.Field(author => author.Nationality);
            descriptor.Field(author => author.Country).Description("Country of Author")
                .Type<CountryType>()
                .Resolve(context => context.Service<CountriesService>().GetCountryForAuthor(context.Parent<AuthorViewModel>()));
            


        }
    }
}
