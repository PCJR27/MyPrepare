﻿using Bookstore.Services;
using Bookstore.ViewModels;

namespace Bookstore.Queries
{
    public class BookType : ObjectType<BookViewModel>
    {
        protected override void Configure(IObjectTypeDescriptor<BookViewModel> descriptor)
        {
            descriptor.Field(b => b.Id);
            descriptor.Field(b => b.Title);
            descriptor.Field(b => b.IsbnCode);
            descriptor.Field(b => b.Price);
            descriptor.Field(b => b.Author).Description("Data of Author")
                .Type<AuthorType>()
                .Resolve(context =>
                context.Service<AuthorService>().GetAuthor(context.Parent<BookViewModel>())); 

            descriptor.Field(b => b.Country)
                .Description("Data Oof Country")
                .Type<CountryType>()
                .Resolve(context =>context.Service<CountriesService>()
                .GetCountryForBook(context.Parent<BookViewModel>()));

            descriptor.Field(b => b.Languages).Description("Data Language")
                .Type<ListType<LanguageType>>()
                .Resolve( context =>
                context.Service<LanguageService>().GetLanguages(context.Parent<BookViewModel>().Languages));
            
         
        }
    }

    public class MyClass
    {
        public int Total { get; set; }
    }
}
