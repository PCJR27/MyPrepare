﻿using Bookstore.ViewModels;

namespace Bookstore.Queries
{
    public class CountryType :ObjectType <CountryViewModel>
    {
        protected override void Configure(IObjectTypeDescriptor<CountryViewModel> descriptor)
        {
            descriptor.Field(country => country.Code);
            descriptor.Field(country => country.Name);


        }
    }
}
