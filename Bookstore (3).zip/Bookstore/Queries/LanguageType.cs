﻿using Bookstore.ViewModels;

namespace Bookstore.Queries
{
    public class LanguageType : ObjectType<LanguageViewModel>
    {
        protected override void Configure(IObjectTypeDescriptor<LanguageViewModel> descriptor)
        {
            descriptor.Field(l => l.LanguageId);
            descriptor.Field(l => l.LanguageName);


        }
    }
}
