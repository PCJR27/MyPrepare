﻿using Bookstore.ViewModels;

namespace Bookstore.Services
{
    public class AuthorService
    {
        List<AuthorViewModel> _authors =
      new List<AuthorViewModel>()
     {
               new AuthorViewModel{
                AuthorId = new Guid("899d3f2b-5c2a-4970-acee-40637fef3f29"),
                Name = "Porcha",
                Nationality = "Chinese",
              //  country = "TH",
                BookId = new Guid("b4d916c4-9094-4fd8-9962-2740156cb8f4")
               },
               new AuthorViewModel{
                AuthorId = new Guid("fc87a061-eee3-4111-9bc4-a9a856114471"),
                Name = "Chapor",
                Nationality ="Thai",
                //country = "US",
               BookId = new Guid("f1cee11d-ac16-4186-a0d8-63b8213c6664"),

               },
               new AuthorViewModel{
                AuthorId = new Guid ("0b8a3959-bfdf-4c09-b2e8-ad478e53610e"),
                Name = "Por",
                Nationality ="Indian",
                //country = "BE",
                BookId = new Guid("d983427c-9b76-4189-9148-ad59ffcfa2c2"),

               },


     };

        public AuthorViewModel GetAuthor(BookViewModel bookData)
        {
            return _authors.Find(author => author.BookId == bookData.Id);
        }

    }
}
