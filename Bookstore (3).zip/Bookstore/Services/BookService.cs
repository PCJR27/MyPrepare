﻿using Bookstore.ViewModels;
using System.Collections.Generic;

namespace Bookstore.Services
{
    public class BookService
    {

      /*  List<AuthorViewModel> _Authors =
          new List<AuthorViewModel>()
         {
               new AuthorViewModel{
                Author_id = new Guid("899d3f2b-5c2a-4970-acee-40637fef3f29"),
                name = "Porcha",
                nationality = "Chinese",
                book_id = new Guid("b4d916c4-9094-4fd8-9962-2740156cb8f4")
               },
               new AuthorViewModel{
                Author_id = new Guid("fc87a061-eee3-4111-9bc4-a9a856114471"),
                name = "Chapor",
                nationality ="Thai",
                book_id = new Guid("f1cee11d-ac16-4186-a0d8-63b8213c6664"),

               },
               new AuthorViewModel{
                Author_id = new Guid ("0b8a3959-bfdf-4c09-b2e8-ad478e53610e"),
                name = "Por",
                nationality ="Indian",
                book_id = new Guid("d983427c-9b76-4189-9148-ad59ffcfa2c2"),

               },


         };*/

       /* List<LanguageViewModel> _languages =
           new List<LanguageViewModel>()
          {
               new LanguageViewModel{
                language_id = new Guid("540b67ad-0505-4308-95cc-c80bf99a9e0e"),
                language_name = "Thai",
                   book_id = new Guid("b4d916c4-9094-4fd8-9962-2740156cb8f4")
               },
               new LanguageViewModel{
                language_id = new Guid("79d823b3-48d2-4199-85dd-e83d4449bf80"),
                language_name = "English",
                 book_id = new Guid("f1cee11d-ac16-4186-a0d8-63b8213c6664")
               },
               new LanguageViewModel{
                language_id = new Guid("76792759-d565-4ef2-b438-5d6d3523d812"),
                language_name = "French",
                book_id = new Guid("d983427c-9b76-4189-9148-ad59ffcfa2c2")
               }

          };*/

      /*  List<CountryViewModel> _countries =
         new List<CountryViewModel>()
        {
              new CountryViewModel{
                code = "TH",
                name = "Thailand",
                book_id = new Guid("b4d916c4-9094-4fd8-9962-2740156cb8f4"),
                 Author_id = new Guid("899d3f2b-5c2a-4970-acee-40637fef3f29"),
                 },
              new CountryViewModel{
                code = "US",
                name = "United States",
                 book_id = new Guid("f1cee11d-ac16-4186-a0d8-63b8213c6664"),
                 Author_id = new Guid("fc87a061-eee3-4111-9bc4-a9a856114471")
               },
              new CountryViewModel{
                code = "BE",
                name = "BELGIUM",
                 book_id = new Guid("d983427c-9b76-4189-9148-ad59ffcfa2c2"),
                 Author_id = new Guid ("0b8a3959-bfdf-4c09-b2e8-ad478e53610e")
               }

        };*/


        List<BookViewModel> _books =
             new List<BookViewModel>()
            {
               new BookViewModel{
                Id = new Guid("b4d916c4-9094-4fd8-9962-2740156cb8f4"),
                Title = "Harry Potter",
                IsbnCode = "B1",
                Price =100,
                Author=new Guid("899d3f2b-5c2a-4970-acee-40637fef3f29"),
                Country = "TH",
                 Languages = new List<Guid>
                {
                    new Guid("540b67ad-0505-4308-95cc-c80bf99a9e0e"),
                     new Guid("76792759-d565-4ef2-b438-5d6d3523d812")
                }


               },
                new BookViewModel{
                Id = new Guid("f1cee11d-ac16-4186-a0d8-63b8213c6664"),
                Title = "The Stars",
                IsbnCode = "B2",
                Price=500,
                Author = new Guid("fc87a061-eee3-4111-9bc4-a9a856114471"),
                Country = "US",
                Languages = new List<Guid>
                {
                    new Guid("79d823b3-48d2-4199-85dd-e83d4449bf80"),
                     new Guid("76792759-d565-4ef2-b438-5d6d3523d812")
                }
               },
                new BookViewModel{
                Id = new Guid("d983427c-9b76-4189-9148-ad59ffcfa2c2"),
                Title = "The Popcorn",
                IsbnCode= "B3",
                Price=500,
                Author =new Guid ("0b8a3959-bfdf-4c09-b2e8-ad478e53610e"),
                Country = "BE",
                Languages = new List<Guid>
                {
                   new Guid("76792759-d565-4ef2-b438-5d6d3523d812")
                }
               }

            };


        public List<BookViewModel> GetBooks()
        {
            return _books;
            /*foreach(var book in _books)
             {
                 foreach(var Author in _Authors)
                 {
                     foreach(var Country in _countries)
                     {
                         foreach(var language in _languages)
                         {
                             if (Author.Author_id == Country.Author_id)
                             {
                                 Author.Country = Country;
                             }
                             if (Author.book_id == book.Id && Country.book_id == book.Id &&language.book_id == book.Id)
                             {
                                 book.Author = Author;
                                 book.Country = Country;
                                 //book.languages = language;

                             }
                         }
                     }
                 }
             }*/


        } 
     /*   public List<AuthorViewModel> GetAuthors()
        {
            List<AuthorViewModel> listAuthor = new List<AuthorViewModel>();

            foreach(var Author in _Authors)
            {
                foreach(var Country in _countries)
                {
                    if(Author.Author_id == Country.Author_id)
                    {
                        Author.Country = Country;
                    }
                }
            }
            return _Authors;

        }*/

       public List<BookViewModel> GetBookByTitle(List<String> titles)
        {
           List<BookViewModel> listBook = new List<BookViewModel>();
            listBook = _books.Where(b => titles.Contains(b.Title)).ToList();
            return listBook;
            /* foreach (var title in titles)
             {
                 foreach (var book in _books)
                 {
                     if (book.Title == title)
                     {
                         listBook.Add(book);
                     }
                 }
             }
             return listBook; */

            /* from b in _books
                where b.Title == 
                select b; */

            

       /*   foreach(var list in listBook)
            {
                foreach(var item in _Authors)
                {
                    foreach(var item2 in _countries)
                    {
                        foreach(var item3 in _languages)
                        {
                            if(item.Author_id == item2.Author_id)
                            {
                                item.Country = item2;
                            }
                            if(item.book_id == list.Id && item2.book_id==list.Id && item3.book_id == list.Id)
                            {
                                list.Author = item;
                                list.Country = item2;
                               // list.languages = item3;

                            }
                        }
                    }
                }
            }*/
          


        }

        public BookViewModel GetOneBook(Guid id)
        {
            BookViewModel book = null;
            book = _books.Find(b => b.Id == id);
            return book;



            /*foreach (var item in _Authors)
            {
                foreach (var item2 in _countries)
                {

                    foreach (var item3 in _languages)
                    {
                        if (item2.Author_id == item.Author_id)
                        {
                            item.Country = item2;
                        }
                        if (item.book_id == id && item2.book_id == id && item3.book_id == id)
                        {
                            book = _books.Find(b => b.Id == id);
                            book.Author = item;
                            book.Country = item2;
                          //  book.languages = item3;
                        }
                    }
                }

            } */



        }
    }
}