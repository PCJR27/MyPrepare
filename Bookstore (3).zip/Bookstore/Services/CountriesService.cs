﻿using Bookstore.ViewModels;

namespace Bookstore.Services
{
    public class CountriesService
    {

        List<CountryViewModel> _countries =
         new List<CountryViewModel>()
        {
              new CountryViewModel{
                Code = "TH",
                Name = "Thailand",
                BookId = new Guid("b4d916c4-9094-4fd8-9962-2740156cb8f4"),
                 AuthorId = new Guid("899d3f2b-5c2a-4970-acee-40637fef3f29")
                 },
              new CountryViewModel{
                Code = "US",
                Name = "United States",
                BookId = new Guid("f1cee11d-ac16-4186-a0d8-63b8213c6664"),
                 AuthorId = new Guid("fc87a061-eee3-4111-9bc4-a9a856114471")
               },
              new CountryViewModel{
                Code = "BE",
                Name = "BELGIUM",
                BookId = new Guid("d983427c-9b76-4189-9148-ad59ffcfa2c2"),
                 AuthorId = new Guid ("0b8a3959-bfdf-4c09-b2e8-ad478e53610e")
               }

        };

        public CountryViewModel GetCountryForBook(BookViewModel bookData)
        {
            return _countries.Find(country => country.BookId == bookData.Id);
        }

        public CountryViewModel GetCountryForAuthor(AuthorViewModel authorData)
        {
            return _countries.Find(country => country.AuthorId == authorData.AuthorId);
        }

    }
}
