﻿namespace Bookstore.ViewModels
{
    public class AuthorViewModel
    {
        public Guid AuthorId { get; set; }
        public string Name { get; set; }
        public string Nationality { get; set; }
        public Guid BookId { get; set; }
        public Guid Country { get; set; }
    }
}
