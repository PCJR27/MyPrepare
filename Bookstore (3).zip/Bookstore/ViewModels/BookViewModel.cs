﻿namespace Bookstore.ViewModels
{
    /// <summary>
    /// Structure of Book
    /// </summary>
    public class BookViewModel
    {
        public Guid Id { get; set; }
        public string Title { get; set; }
        public string IsbnCode { get; set; }
        public int Price { get; set; }

        public Guid Author { get; set; }
        public List<Guid> Languages { get; set; }
        public string Country { get; set; }
    }
}
