﻿namespace Bookstore.ViewModels
{
    public class CountryViewModel
    {
        public string Code { get; set; }
        public string Name { get; set; }
        public Guid BookId { get; set; }
        public Guid AuthorId { get; set; }
    }
}
