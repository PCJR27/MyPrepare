﻿namespace Bookstore.ViewModels
{
    public class LanguageViewModel
    {
        public Guid  LanguageId { get; set; }
        public string LanguageName { get; set; }
    }
}
