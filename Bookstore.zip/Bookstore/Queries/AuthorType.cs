﻿using Bookstore.ViewModels;

namespace Bookstore.Queries
{
    public class AuthorType :ObjectType<AuthorViewModel>
    {
        protected override void Configure(IObjectTypeDescriptor<AuthorViewModel> descriptor)
        {
            descriptor.Field(a => a.author_id);
            descriptor.Field(a => a.name);
            


        }
    }
}
