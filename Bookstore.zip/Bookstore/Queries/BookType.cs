﻿using Bookstore.ViewModels;

namespace Bookstore.Queries
{
    public class BookType : ObjectType<BookViewModel>
    {
        protected override void Configure(IObjectTypeDescriptor<BookViewModel> descriptor)
        {
            descriptor.Field(b => b.Id);
            descriptor.Field(b => b.Title);
            descriptor.Field(b => b.isbnCode);
            descriptor.Field(b => b.price);
            descriptor.Field(b => b.author);
            descriptor.Field(b => b.country);
            descriptor.Field(b => b.languages);
            
         
        }
    }
}
