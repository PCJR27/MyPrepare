﻿using Bookstore.ViewModels;

namespace Bookstore.Queries
{
    public class LanguageType : ObjectType<LanguageViewModel>
    {
        protected override void Configure(IObjectTypeDescriptor<LanguageViewModel> descriptor)
        {
            descriptor.Field(l => l.language_id);
            descriptor.Field(l => l.language_name);


        }
    }
}
