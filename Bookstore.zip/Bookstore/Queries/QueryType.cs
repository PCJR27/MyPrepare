﻿using Bookstore.Services;

namespace Bookstore.Queries
{
    public class QueryType :ObjectType
    {
        protected override void Configure(IObjectTypeDescriptor descriptor)
        {
            descriptor.Field("books").Description("Get All of the book")
                .Type<ListType<BookType>>()
                .Resolve(context => context.Service<BookService>().GetBooks());

            descriptor.Field("book")
      .Description("Get a book")
      .Argument("id", a => a.Type<IdType>())
      .Type<BookType>()
      .Resolve(context => context.Service<BookService>().GetOneBook(context.ArgumentValue<Guid>("id")));

            descriptor.Field("author").Description("Get All Author")
                    .Type<ListType<AuthorType>>()
                    .Resolve(context => context.Service<BookService>().GetAuthors());

        }
    }
}
