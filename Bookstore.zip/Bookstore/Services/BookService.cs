﻿using Bookstore.ViewModels;

namespace Bookstore.Services
{
    public class BookService
    {

        List<AuthorViewModel> _authors =
          new List<AuthorViewModel>()
         {
               new AuthorViewModel{
                author_id = new Guid("899d3f2b-5c2a-4970-acee-40637fef3f29"),
                name = "Porcha",
                nationality = "Chinese",
                book_id = new Guid("b4d916c4-9094-4fd8-9962-2740156cb8f4")
               },
               new AuthorViewModel{
                author_id = new Guid("fc87a061-eee3-4111-9bc4-a9a856114471"),
                name = "Chapor",
                nationality ="Thai",
                book_id = new Guid("f1cee11d-ac16-4186-a0d8-63b8213c6664"),
                
               }

         };

        List<LanguageViewModel> _languages =
           new List<LanguageViewModel>()
          {
               new LanguageViewModel{
                language_id = Guid.NewGuid(),
                language_name = "Thai",
                   book_id = new Guid("b4d916c4-9094-4fd8-9962-2740156cb8f4")
               },
                   new LanguageViewModel{
                language_id = Guid.NewGuid(),
                language_name = "English",
                 book_id = new Guid("f1cee11d-ac16-4186-a0d8-63b8213c6664"),
               }

          };

        List<CountryViewModel> _countries =
         new List<CountryViewModel>()
        {
               new CountryViewModel{
                code = "TH",
                name = "Thailand",
                book_id = new Guid("b4d916c4-9094-4fd8-9962-2740156cb8f4"),
                 author_id = new Guid("899d3f2b-5c2a-4970-acee-40637fef3f29"),
               },
                   new CountryViewModel{
                code = "US",
                name = "United States",
                 book_id = new Guid("f1cee11d-ac16-4186-a0d8-63b8213c6664"),
                 author_id = new Guid("fc87a061-eee3-4111-9bc4-a9a856114471"),
               }

        };


        List<BookViewModel> _books =
             new List<BookViewModel>()
            {
               new BookViewModel{
                Id = new Guid("b4d916c4-9094-4fd8-9962-2740156cb8f4"),
                Title = "Harry Potter",
                isbnCode = "B1",
                price =100,
        

               },
                new BookViewModel{
                Id = new Guid("f1cee11d-ac16-4186-a0d8-63b8213c6664"),
                Title = "The Stars",
                 isbnCode = "B2",
                 price=500,
               }

            };

       
        public List<BookViewModel> GetBooks(List<String> titles)
        {
            return _books;
        }
        public List<AuthorViewModel> GetAuthors()
        {
            return _authors;
        }

        public BookViewModel GetOneBook (Guid id)
        {
            BookViewModel book = null;
            foreach (var item in _authors)
            {
                foreach(var item2 in _countries)
                {
                    
                    foreach (var item3 in _languages)
                    {
                        if(item2.author_id == item.author_id)
                        {
                            item.country = item2;
                        }
                        if (item.book_id == id && item2.book_id==id && item3.book_id==id)
                        {
                            book = _books.Find(b => b.Id == id);
                            book.author = item;
                            book.country = item2;
                            book.languages = item3;
                        }
                    }
                }
               
            }
                return book ;
        

        }
    }
}
