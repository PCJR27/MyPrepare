﻿namespace Bookstore.ViewModels
{
    public class AuthorViewModel
    {
        public Guid author_id { get; set; }
        public string name { get; set; }
        public string nationality { get; set; }
        public Guid book_id { get; set; }
        public CountryViewModel country { get; set; }
    }
}
