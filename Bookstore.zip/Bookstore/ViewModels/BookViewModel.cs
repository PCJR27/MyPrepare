﻿namespace Bookstore.ViewModels
{
    public class BookViewModel
    {
        public Guid Id { get; set; }
        public string Title { get; set; }
        public string isbnCode { get; set; }
        public int price { get; set; }

        public AuthorViewModel author { get; set; }
        public LanguageViewModel languages { get; set; }
        public CountryViewModel country { get; set; }
    }
}
