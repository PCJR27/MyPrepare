﻿namespace Bookstore.ViewModels
{
    public class LanguageViewModel
    {
        public Guid language_id { get; set; }
        public string language_name { get; set; }
        public Guid book_id { get; set; }
    }
}
