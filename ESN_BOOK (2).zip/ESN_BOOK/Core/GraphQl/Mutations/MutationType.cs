﻿using Bookstore.Core.Services.Books;
using Bookstore.Domains.GraphQl.Mutations.InputModels;
using Bookstore.Domains.GraphQl.Mutations.InputType;
using Bookstore.Domains.GraphQl.Queries;
using Bookstore.ViewModels;

namespace Bookstore.Core.GraphQl.Mutations
{
    public class MutationType : ObjectType
    {
        protected override void Configure(
         IObjectTypeDescriptor descriptor)
        {
            descriptor.Field("addBook")
                    .Argument("newBook", newBook => newBook.Type<NonNullType<BookInputType>>())
                    .Type<BookType>()
                    .Resolve(context =>
                           context.Service<BookService>().AddNewBook(context.ArgumentValue<BookCreateModel>("newBook"))
                    );
            descriptor.Field("updateBook")
                .Argument("editBook", editBook => editBook.Type<NonNullType<BookInputUpdateType>>())
                .Argument("idBook", idBook => idBook.Type<NonNullType<IdType>>())
                .Type<BookType>()
                .Resolve(context => context.Service<BookService>().UpdateBook(context.ArgumentValue<Guid>("idBook"), context.ArgumentValue<BookUpdateModel>("editBook")));

            descriptor.Field("deleteBook")
                .Argument("deleteId", deleteId => deleteId.Type<NonNullType<IdType>>())
                .Type<BooleanType>()
                .Resolve(context => context.Service<BookService>().DeleteBook(context.ArgumentValue<Guid>("deleteId")));
        }
    }
}