﻿using Bookstore.Core.Services.Books;
using Bookstore.Domains.GraphQl.Queries;
using Bookstore.Domains.Services;

namespace Bookstore.Core.GraphQl.Query
{
    /// <summary>
    /// class it tell structure to hot chocolate
    /// </summary>
    /// <seealso cref="ObjectType" />
    public class QueryType : ObjectType
    {
        /// <summary>
        /// Override this to configure the type.
        /// </summary>
        /// <param name="descriptor">The descriptor allows to configure the interface type.</param>
        protected override void Configure(IObjectTypeDescriptor descriptor)
        {
            descriptor.Field("books")
               .Description("Get all books")
               .Argument("titles", a => a.Type<ListType<StringType>>().Description("Filter By Title Name"))
               .Type<ListType<BookType>>()
               .Resolve(context =>
                context.Service<BookService>()
                    .GetBooks(context.ArgumentValue<List<string>>("titles"))
               );

            descriptor.Field("book")
               .Description("Get a book")
               .Argument("id", a => a.Type<NonNullType<IdType>>())
               .Type<BookType>()
               .Resolve(context => context.Service<BookService>().GetOneBook(context.ArgumentValue<Guid>("id")));

            descriptor.Field("author")
               .Description("Get All Author")
               .Type<ListType<AuthorType>>()
               .Resolve(context => context.Service<AuthorService>().GetAuthors());
        }
    }
}