﻿using Bookstore.Core.Models.View;

namespace Bookstore.Core.Repositories.AuthorsRepo
{
    /// <summary>
    /// Template actions performed with Author information
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public interface IAuthorRepositories
    {
        List<AuthorViewModel> GetAll();

        AuthorViewModel GetByBookId(Guid id);
    }
}