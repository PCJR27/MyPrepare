﻿using Bookstore.Core.Models;
using Bookstore.Domains.Data.Book;

namespace Bookstore.Core.Repositories.Books
{
    public class BookRepositories : IBookRepositories<BookViewModel>
    {
        
        public BookViewModel Add(BookViewModel book)
        {
            var newBook = new BookViewModel
            {
                BookId = Guid.NewGuid(),
                Title = book.Title,
                Author = book.Author,
                Languages = book.Languages
            };
            _books.Add(newBook);

            return newBook;
        }

        public void Delete(Guid id)
        {
            throw new NotImplementedException();
        }

        public List<BookViewModel> GetAll()
        {
            throw new NotImplementedException();
        }

        public BookViewModel GetById(Guid id)
        {
            throw new NotImplementedException();
        }

        public void Update(Guid id, BookViewModel entity)
        {
            throw new NotImplementedException();
        }
    }
}
