﻿namespace Bookstore.Core.Repositories.Books
{
    public interface IBookRepositories<T>
    {
        T GetById(Guid id);
        List<T> GetAll();
        T Add(T entity);
        void Update(Guid id,T entity);
        void Delete(Guid id);
    }
}
