﻿using Bookstore.Core.DBContext;
using Bookstore.Core.Models.Input;
using Bookstore.Core.Models.View;

namespace Bookstore.Core.Repositories.BooksRepo
{
    /// <summary>
    /// Store actions performed with Book information
    /// </summary>
    /// <seealso cref="Bookstore.Core.Repositories.BooksRepo.IBookRepositories&lt;BookViewModel&gt;" />
    public class BookRepositories : IBookRepositories
    {
        /// <summary>
        /// The author context
        /// </summary>
        private readonly DataBaseContext _dataContext;

        /// <summary>
        /// Initializes a new instance of the <see cref="AuthorRepositories"/> class.
        /// </summary>
        /// <param name="authorContext">The author context.</param>
        /// <exception cref="System.ArgumentNullException">authorContext</exception>
        public BookRepositories(DataBaseContext dataContext) =>
        _dataContext = dataContext ?? throw new ArgumentNullException(nameof(dataContext));

        /// <summary>
        /// Adds the specified book.
        /// </summary>
        /// <param name="book">The book.</param>
        /// <returns></returns>
        public BookViewModel Add(BookCreateModel book)
        {
            var newBook = new BookViewModel
            {
                BookId = Guid.NewGuid(),
                Title = book.Title,
                Author = book.Author,
                Languages = book.Language,
                Country = book.Country ?? null,
                IsbnCode = book.IsbnCode ?? null,
                Price = book.Price ?? null
            };
            _dataContext.GetBooks().Add(newBook);
            return newBook;
        }

        /// <summary>
        /// Deletes the specified identifier.
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <returns></returns>
        /// <exception cref="InvalidOperationException">Book with ID {id} not found.</exception>
        public bool Delete(Guid id)
        {
            BookViewModel bookDelete = _dataContext.GetBooks().Find(book => book.BookId == id) ??
           throw new InvalidOperationException($"Book with ID {id} not found.");
            return _dataContext.GetBooks().Remove(bookDelete); ;
        }

        /// <summary>
        /// Gets all.
        /// </summary>
        /// <param name="titles">The titles.</param>
        /// <returns></returns>
        public List<BookViewModel> GetAll(List<string> titles)
        {
            if (titles != null && titles.Any())
            {
                List<BookViewModel> listBook = new();
                listBook = _dataContext.GetBooks().Where(book => titles.Any(title =>
                !title.Trim().Equals("") &&
                 book.Title.ToLower()
                .Contains(title.Trim().ToLower())))
                .ToList();

                return listBook;
            }

            return _dataContext.GetBooks();
        }

        /// <summary>
        /// Gets the by identifier.
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <returns></returns>
        public BookViewModel GetById(Guid id)
        {
            return _dataContext.GetBooks().Find(b => b.BookId == id);
        }

        /// <summary>
        /// Updates the specified identifier.
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <param name="editBook">The edit book.</param>
        /// <returns></returns>
        /// <exception cref="InvalidOperationException">Book with ID {id} not found.</exception>
        public BookViewModel Update(Guid id, BookUpdateModel editBook)
        {
            BookViewModel selectedBook = _dataContext.GetBooks().Find(book => book.BookId == id);

            if (selectedBook != null)
            {
                selectedBook.Title = editBook.Title ?? selectedBook.Title;
                selectedBook.Author = editBook.Author ?? selectedBook.Author;
                selectedBook.Languages = editBook.Language ?? selectedBook.Languages;
                selectedBook.Price = editBook.Price ?? selectedBook.Price;
                selectedBook.Country = editBook.Country ?? selectedBook.Country;
            }
            else
            {
                throw new InvalidOperationException($"Book with ID {id} not found.");
            }

            return selectedBook;
        }
    }
}