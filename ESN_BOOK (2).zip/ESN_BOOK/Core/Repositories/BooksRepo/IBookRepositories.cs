﻿using Bookstore.Core.Models.Input;
using Bookstore.Core.Models.View;

namespace Bookstore.Core.Repositories.BooksRepo
{
    /// <summary>
    /// Template actions performed with Book information
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public interface IBookRepositories
    {
        List<BookViewModel> GetAll(List<string> titles);

        BookViewModel Add(BookCreateModel book);

        BookViewModel Update(Guid id, BookUpdateModel entity);

        bool Delete(Guid id);

        BookViewModel GetById(Guid id);
    }
}