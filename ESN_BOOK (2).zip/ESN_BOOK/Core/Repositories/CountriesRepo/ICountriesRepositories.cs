﻿using Bookstore.Core.Models.View;

namespace Bookstore.Core.Repositories.CountriesRepo
{
    /// <summary>
    /// Template actions performed with Country information
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public interface ICountriesRepositories
    {
        CountryViewModel GetById(string data);
    }
}