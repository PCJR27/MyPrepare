﻿using Bookstore.Core.Models.View;

namespace Bookstore.Core.Repositories.LanguagesRepo
{
    /// <summary>
    /// Template actions performed with Language information
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public interface ILanguageRepositories
    {
        List<LanguageViewModel> GetById(List<Guid> id);
    }
}