﻿using Bookstore.Core.DBContext;
using Bookstore.Core.Models.View;
using Bookstore.Core.Repositories.AuthorsRepo;

namespace Bookstore.Core.Services
{
    /// <summary>
    /// it provide author can do and can easy to use it because it provide what you want to use when call Author Structure
    /// </summary>
    public class AuthorService
    {
        /// <summary>
        /// The author repositories
        /// </summary>
        private readonly AuthorRepositories _authorRepositories;

        /// <summary>
        /// Initializes a new instance of the <see cref="AuthorService"/> class.
        /// </summary>
        /// <param name="authorRepositories">The author repositories.</param>
        /// <exception cref="ArgumentNullException">authorRepositories</exception>
        public AuthorService(AuthorRepositories authorRepositories)
        {
            _authorRepositories = authorRepositories ?? throw new ArgumentNullException(nameof(authorRepositories));
        }

        /// <summary>
        /// Gets the author.
        /// </summary>
        /// <param name="bookData">The book data.</param>
        /// <returns></returns>
        public AuthorViewModel GetAuthor(Guid bookData) =>
        _authorRepositories.GetByBookId(bookData);

        /// <summary>
        /// Gets the authors.
        /// </summary>
        /// <returns></returns>
        public List<AuthorViewModel> GetAuthors() =>
         _authorRepositories.GetAll();
    }
}