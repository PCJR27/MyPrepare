﻿using Bookstore.Core.DBContext;
using Bookstore.Core.Models.Input;
using Bookstore.Core.Models.View;
using Bookstore.Core.Repositories.BooksRepo;

namespace Bookstore.Core.Services
{
    /// <summary>
    ///  it provide book can do and can easy to use it because it provide what you want to use when call book Structure
    /// </summary>
    public class BookService
    {
        /// <summary>
        /// The book repositories
        /// </summary>
        private readonly BookRepositories _bookRepositories;

        /// <summary>
        /// Initializes a new instance of the <see cref="BookService"/> class.
        /// </summary>
        /// <param name="bookRepo">The book repo.</param>
        /// <exception cref="ArgumentNullException">bookRepo</exception>
        public BookService(BookRepositories bookRepo)
        {
            _bookRepositories = bookRepo ?? throw new ArgumentNullException(nameof(bookRepo));
        }

        /// <summary>
        /// Gets the books.
        /// </summary>
        /// <param name="titles">The titles.</param>
        /// <returns></returns>
        public List<BookViewModel> GetBooks(List<string> titles) => _bookRepositories.GetAll(titles);

        /// <summary>
        /// Gets the one book.
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <returns></returns>
        public BookViewModel GetOneBook(Guid id) =>
            _bookRepositories.GetById(id);

        /// <summary>
        /// Adds the new book.
        /// </summary>
        /// <param name="book">The book.</param>
        /// <returns></returns>
        public BookViewModel AddNewBook(BookCreateModel book) =>
            _bookRepositories.Add(book);

        /// <summary>
        /// Updates the book.
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <param name="editBook">The edit book.</param>
        /// <returns></returns>
        /// <exception cref="InvalidOperationException">Book with ID {id} not found.</exception>
        public BookViewModel UpdateBook(Guid id, BookUpdateModel editBook) =>
            _bookRepositories.Update(id, editBook);

        /// <summary>
        /// Deletes the book.
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <returns></returns>
        /// <exception cref="InvalidOperationException">Book with ID {id} not found.</exception>
        public bool DeleteBook(Guid id) =>
            _bookRepositories.Delete(id);
    }
}