﻿using Bookstore.Core.Models;
using Bookstore.Domains.GraphQl.Mutations.InputModels;

namespace Bookstore.Core.Services.Books
{
    /// <summary>
    ///  it provide book can do and can easy to use it because it provide what you want to use when call book Structure
    /// </summary>
    public class BookService
    {
        private readonly List<BookViewModel> _books =
             new()
            {
               new BookViewModel{
                BookId = new Guid("b4d916c4-9094-4fd8-9962-2740156cb8f4"),
                Title = "Harry Potter",
                IsbnCode = "B1",
                Price =100,
                Author=new Guid("899d3f2b-5c2a-4970-acee-40637fef3f29"),
                Country = "TH",
                 Languages = new List<Guid>
                {
                    new("540b67ad-0505-4308-95cc-c80bf99a9e0e"),
                     new("76792759-d565-4ef2-b438-5d6d3523d812")
                }
               },
                new BookViewModel{
                BookId = new Guid("f1cee11d-ac16-4186-a0d8-63b8213c6664"),
                Title = "The Stars",
                IsbnCode = "B2",
                Price=500,
                Author = new Guid("fc87a061-eee3-4111-9bc4-a9a856114471"),
                Country = "US",
                Languages = new List<Guid>
                {
                    new("79d823b3-48d2-4199-85dd-e83d4449bf80"),
                     new("76792759-d565-4ef2-b438-5d6d3523d812")
                }
               },
                new BookViewModel{
                BookId = new Guid("d983427c-9b76-4189-9148-ad59ffcfa2c2"),
                Title = "The Popcorn",
                IsbnCode= "B3",
                Price=700,
                Author =new Guid ("0b8a3959-bfdf-4c09-b2e8-ad478e53610e"),
                Country = "BE",
                Languages = new List<Guid>
                {
                   new("76792759-d565-4ef2-b438-5d6d3523d812")
                }
               }
            };

        /// <summary>
        /// Gets the books.
        /// </summary>
        /// <param name="titles">The titles.</param>
        /// <returns></returns>
        public List<BookViewModel> GetBooks(List<string> titles)
        {
            if (titles != null && titles.Any())
            {
                List<BookViewModel> listBook = new();
                listBook = _books.Where(book => titles.Any(title =>
                !title.Trim().Equals("") &&
                 book.Title.ToLower()
                .Contains(title.Trim().ToLower())))
                .ToList();

                return listBook;
            }

            return _books;
        }

        /*  private List<BookViewModel> GetBookByTitle()
          {
              List<BookViewModel> listBook = new List<BookViewModel>();
              listBook = _books.Where(b => titles.Contains(b.Title)).ToList();
              return listBook;
          }*/

        public BookViewModel GetOneBook(Guid id) =>
            _books.Find(b => b.BookId == id);

        public BookViewModel AddNewBook(BookCreateModel book)
        {
            var newBook = new BookViewModel
            {
                BookId = Guid.NewGuid(),
                Title = book.Title,
                Author = book.Author,
                Languages = book.Language
            };
            _books.Add(newBook);

            return newBook;
        }

        public BookViewModel UpdateBook(Guid id, BookUpdateModel editBook)
        {
            BookViewModel selectedBook = _books.Find(book => book.BookId == id);

            if (selectedBook != null)
            {
                selectedBook.Title = editBook.Title ?? selectedBook.Title;
                selectedBook.Author = editBook.Author ?? selectedBook.Author;
                selectedBook.Languages = editBook.Language ?? selectedBook.Languages;
                selectedBook.Price = editBook.Price ?? selectedBook.Price;
                selectedBook.Country = editBook.Country ?? selectedBook.Country;
            }
            else
            {
                throw new InvalidOperationException($"Book with ID {id} not found.");
            }

            return selectedBook;
        }

        public bool DeleteBook(Guid id)
        {
            BookViewModel bookDelete = _books.Find(book => book.BookId == id) ?? throw new InvalidOperationException($"Book with ID {id} not found.");
            _books.Remove(bookDelete);
            return true;
        }

        /*   public List<AuthorViewModel> GetAuthors()
        {
            List<AuthorViewModel> listAuthor = new List<AuthorViewModel>();

            foreach(var Author in _Authors)
            {
                foreach(var Country in _countries)
                {
                    if(Author.Author_id == Country.Author_id)
                    {
                        Author.Country = Country;
                    }
                }
            }
            return _Authors;
        }*/
    }
}