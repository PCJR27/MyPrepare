﻿using Bookstore.Core.DBContext;
using Bookstore.Core.Models.View;
using Bookstore.Core.Repositories.LanguagesRepo;

namespace Bookstore.Core.Services
{
    /// <summary>
    ///  it provide language can do and can easy to use it because it provide what you want to use when call language Structure
    /// </summary>
    public class LanguageService
    {
        /// <summary>
        /// The languages repositories
        /// </summary>
        private readonly LanguageRepositories _languagesRepositories;

        /// <summary>
        /// Initializes a new instance of the <see cref="LanguageService"/> class.
        /// </summary>
        /// <param name="languagesRepositories">The languages repositories.</param>
        /// <exception cref="ArgumentNullException">languagesRepositories</exception>
        public LanguageService(LanguageRepositories languagesRepositories)
        {
            _languagesRepositories = languagesRepositories ?? throw new ArgumentNullException(nameof(languagesRepositories));
        }

        /// <summary>
        /// Gets the languages.
        /// </summary>
        /// <param name="bookDataLanguage">The book data language.</param>
        /// <returns></returns>
        public List<LanguageViewModel> GetLanguages(List<Guid> bookDataLanguage)
             => _languagesRepositories.GetById(bookDataLanguage);
    }
}