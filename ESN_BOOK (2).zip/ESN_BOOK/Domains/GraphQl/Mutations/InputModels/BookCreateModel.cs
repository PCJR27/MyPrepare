﻿using Bookstore.ViewModels;

namespace Bookstore.Domains.GraphQl.Mutations.InputModels
{
    public class BookCreateModel
    {
        public string Title { get; set; }
        public Guid Author { get; set; }
        public string IsbnCode { get; set; }
        public int? Price { get; set; }
        public string Country { get; set; }
        public List<Guid> Language { get; set; }
    }
}