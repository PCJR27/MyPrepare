﻿namespace Bookstore.Domains.GraphQl.Mutations.InputModels
{
    public class BookUpdateModel
    {
        public string Title { get; set; }
        public Guid? Author { get; set; }
        public List<Guid> Language { get; set; }
        public int? Price { get; set; }
        public string Country { get; set; }
    }
}