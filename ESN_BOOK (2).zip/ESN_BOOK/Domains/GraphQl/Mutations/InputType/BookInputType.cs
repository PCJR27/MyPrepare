﻿using Bookstore.Domains.GraphQl.Mutations.InputModels;

namespace Bookstore.Domains.GraphQl.Mutations.InputType
{
    public class BookInputType : InputObjectType<BookCreateModel>
    {
        protected override void Configure(IInputObjectTypeDescriptor<BookCreateModel> descriptor)
        {
            descriptor.Field("title").Type<NonNullType<StringType>>();
            descriptor.Field("author").Type<NonNullType<IdType>>();
            descriptor.Field("language").Type<NonNullType<ListType<IdType>>>();
            descriptor.Field("country").Type<StringType>();
            descriptor.Field("price").Type<IntType>();
            descriptor.Field(isbn => isbn.IsbnCode).Type<StringType>();
        }
    }
}