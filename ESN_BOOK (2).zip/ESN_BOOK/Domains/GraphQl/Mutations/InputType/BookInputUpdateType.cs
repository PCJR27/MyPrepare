﻿using Bookstore.Domains.GraphQl.Mutations.InputModels;

namespace Bookstore.Domains.GraphQl.Mutations.InputType
{
    public class BookInputUpdateType : InputObjectType<BookUpdateModel>
    {
        protected override void Configure(IInputObjectTypeDescriptor<BookUpdateModel> descriptor)
        {
            descriptor.Field(title => title.Title).Type<StringType>();
            descriptor.Field(author => author.Author).Type<IdType>();
            descriptor.Field(language => language.Language).Type<ListType<IdType>>();
            descriptor.Field(price => price.Price).Type<IntType>();
            descriptor.Field(countries => countries.Country).Type<StringType>();
        }
    }
}