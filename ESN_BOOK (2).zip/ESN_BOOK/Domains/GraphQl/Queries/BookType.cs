﻿using Bookstore.Core.Models;
using Bookstore.Domains.Services;

namespace Bookstore.Domains.GraphQl.Queries
{
    /// <summary>
    /// class it tell structure to hot chocolate
    /// </summary>
    /// <seealso cref="ObjectType&lt;BookViewModel&gt;" />
    public class BookType : ObjectType<BookViewModel>
    {
        /// <summary>
        /// Override this to configure the type.
        /// </summary>
        /// <param name="descriptor">The descriptor allows to configure the interface type.</param>
        protected override void Configure(IObjectTypeDescriptor<BookViewModel> descriptor)
        {
            descriptor.Name("Book");
            descriptor.Field("id").Type<IdType>()
                .Resolve(context => context.Parent<BookViewModel>().BookId);
            // descriptor.Field(b => b.BookId);
            descriptor.Field(b => b.Title);
            descriptor.Field(b => b.IsbnCode);
            descriptor.Field(b => b.Price);
            descriptor.Field(b => b.Author)
                .Description("Data of Author")
                .Type<AuthorType>()
                .Resolve(context =>
                context.Service<AuthorService>()
                .GetAuthor(context.Parent<BookViewModel>().Author));

            descriptor.Field(b => b.Country)
                .Description("Data Of Country")
                .Type<CountryType>()
                .Resolve(context => context.Service<CountriesService>()
                .GetCountryForBook(context.Parent<BookViewModel>().Country));

            descriptor.Field(b => b.Languages).Description("Data Language")
                .Type<ListType<LanguageType>>()
                .Resolve(context =>
                context.Service<LanguageService>()
                .GetLanguages(context.Parent<BookViewModel>().Languages));
        }
    }
}