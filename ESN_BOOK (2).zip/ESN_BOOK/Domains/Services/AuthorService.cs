﻿using Bookstore.Domains.Models;

namespace Bookstore.Domains.Services
{
    /// <summary>
    /// it provide author can do and can easy to use it because it provide what you want to use when call Author Structure
    /// </summary>
    public class AuthorService
    {
        private readonly List<AuthorViewModel> _authors =
      new()
     {
               new AuthorViewModel{
                AuthorId = new Guid("899d3f2b-5c2a-4970-acee-40637fef3f29"),
                Name = "Porcha",
                Nationality = "Chinese",
                Country = "TH",
                //BookId = new Guid("b4d916c4-9094-4fd8-9962-2740156cb8f4")
               },
               new AuthorViewModel{
                AuthorId = new Guid("fc87a061-eee3-4111-9bc4-a9a856114471"),
                Name = "Chapor",
                Nationality ="Thai",
                Country = "US",
               //BookId = new Guid("f1cee11d-ac16-4186-a0d8-63b8213c6664"),
               },
               new AuthorViewModel{
                AuthorId = new Guid ("0b8a3959-bfdf-4c09-b2e8-ad478e53610e"),
                Name = "Por",
                Nationality ="Indian",
                Country = "BE",
                //BookId = new Guid("d983427c-9b76-4189-9148-ad59ffcfa2c2"),
               },
     };

        public AuthorViewModel GetAuthor(Guid bookData) =>
        _authors.Find(author => author.AuthorId == bookData);

        public List<AuthorViewModel> GetAuthors() =>
         _authors;
    }
}