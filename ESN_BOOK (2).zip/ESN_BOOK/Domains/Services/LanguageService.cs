﻿using Bookstore.Domains.Models;

namespace Bookstore.Domains.Services
{
    /// <summary>
    ///  it provide language can do and can easy to use it because it provide what you want to use when call language Structure
    /// </summary>
    public class LanguageService
    {
        private readonly List<LanguageViewModel> _languages =
         new()
        {
               new LanguageViewModel{
                LanguageId = new Guid("540b67ad-0505-4308-95cc-c80bf99a9e0e"),
                LanguageName = "Thai",
               /* BookId =
                   new List<Guid>{
                   new Guid("b4d916c4-9094-4fd8-9962-2740156cb8f4")
                   }*/
               },
               new LanguageViewModel{
                LanguageId = new Guid("79d823b3-48d2-4199-85dd-e83d4449bf80"),
                LanguageName = "English",
                /*BookId = new List<Guid>()
                {
                    new Guid("b4d916c4-9094-4fd8-9962-2740156cb8f4"),
                    new Guid("d983427c-9b76-4189-9148-ad59ffcfa2c2")
                }*/
               },
               new LanguageViewModel{
                LanguageId = new Guid("76792759-d565-4ef2-b438-5d6d3523d812"),
                LanguageName = "French",
              /*  BookId =
                   new List<Guid>{
                   new Guid("d983427c-9b76-4189-9148-ad59ffcfa2c2")
                   }*/
               }
        };

        public List<LanguageViewModel> GetLanguages(List<Guid> bookDataLanguage)
             => _languages.Where(languageList => bookDataLanguage
                    .Contains(languageList.LanguageId))
                    .ToList();

        //public List<LanguageViewModel> AddNewLanguage(List<LanguageViewModel> languageList)
        //{
        //    var newLa
        //}
    }
}