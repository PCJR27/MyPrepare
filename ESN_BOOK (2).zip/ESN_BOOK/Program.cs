using Bookstore.Core.GraphQl.Mutations;
using Bookstore.Core.GraphQl.Query;
using Bookstore.Core.Services.Books;
using Bookstore.Domains.Services;
using HotChocolate.AspNetCore;

var builder = WebApplication.CreateBuilder(args);
builder.Services
    .AddGraphQLServer()
    .AddQueryType<QueryType>()
    .AddMutationType<MutationType>();
builder.Services.AddSingleton<BookService>();
builder.Services.AddSingleton<AuthorService>();
builder.Services.AddSingleton<CountriesService>();
builder.Services.AddSingleton<LanguageService>();
var app = builder.Build();
//string _graphqlEndpoint = "/graphql";
//string _playgroundEndpoint = "/ui/playground";

app.MapGraphQL("/");
// Add 'UseRouting' middleware before 'UseEndpoints'
//app.UseRouting();
//app.UsePlayground(queryPath: _graphqlEndpoint, uiPath: _playgroundEndpoint);
//app.MapGraphQL();
//app.UseEndpoints(endpoints =>
//{
//    // Add your endpoint configurations here
//    endpoints.MapGraphQL("/");
//});
//app.MapGet("/", () => "Hello World!");

app.Run();