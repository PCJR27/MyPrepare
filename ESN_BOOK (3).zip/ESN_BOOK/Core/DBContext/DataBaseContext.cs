﻿using Bookstore.Core.Models.View;

namespace Bookstore.Core.DBContext
{
    public class DataBaseContext
    {
        /// <summary>
        /// The books
        /// </summary>
        private readonly List<BookViewModel> _books =
           new()
          {
               new BookViewModel{
                BookId = new Guid("b4d916c4-9094-4fd8-9962-2740156cb8f4"),
                Title = "Harry Potter",
                IsbnCode = "B1",
                Price =100,
                Author=new Guid("899d3f2b-5c2a-4970-acee-40637fef3f29"),
                Country = "TH",
                 Languages = new List<Guid>
                {
                    new("540b67ad-0505-4308-95cc-c80bf99a9e0e"),
                     new("76792759-d565-4ef2-b438-5d6d3523d812")
                }
               },
                new BookViewModel{
                BookId = new Guid("f1cee11d-ac16-4186-a0d8-63b8213c6664"),
                Title = "The Stars",
                IsbnCode = "B2",
                Price=500,
                Author = new Guid("fc87a061-eee3-4111-9bc4-a9a856114471"),
                Country = "US",
                Languages = new List<Guid>
                {
                    new("79d823b3-48d2-4199-85dd-e83d4449bf80"),
                     new("76792759-d565-4ef2-b438-5d6d3523d812")
                }
               },
                new BookViewModel{
                BookId = new Guid("d983427c-9b76-4189-9148-ad59ffcfa2c2"),
                Title = "The Popcorn",
                IsbnCode= "B3",
                Price=700,
                Author =new Guid ("0b8a3959-bfdf-4c09-b2e8-ad478e53610e"),
                Country = "BE",
                Languages = new List<Guid>
                {
                   new("76792759-d565-4ef2-b438-5d6d3523d812")
                }
               }
          };

        /// <summary>
        /// The countries
        /// </summary>
        private readonly List<CountryViewModel> _countries =
         new()
        {
              new CountryViewModel{
                CountryId = "TH",
                Name = "Thailand"
                 //BookId = new Guid("b4d916c4-9094-4fd8-9962-2740156cb8f4"),
                 //AuthorId = new Guid("899d3f2b-5c2a-4970-acee-40637fef3f29")
                 },
              new CountryViewModel{
                CountryId = "US",
                Name = "United States"
                //BookId = new Guid("f1cee11d-ac16-4186-a0d8-63b8213c6664"),
                 //AuthorId = new Guid("fc87a061-eee3-4111-9bc4-a9a856114471")
               },
              new CountryViewModel{
                CountryId = "BE",
                Name = "BELGIUM"
                //BookId = new Guid("d983427c-9b76-4189-9148-ad59ffcfa2c2"),
                 //AuthorId = new Guid ("0b8a3959-bfdf-4c09-b2e8-ad478e53610e")
               }
        };

        /// <summary>
        /// The languages
        /// </summary>
        private readonly List<LanguageViewModel> _languages =
        new()
       {
               new LanguageViewModel{
                LanguageId = new Guid("540b67ad-0505-4308-95cc-c80bf99a9e0e"),
                LanguageName = "Thai",
               /* BookId =
                   new List<Guid>{
                   new Guid("b4d916c4-9094-4fd8-9962-2740156cb8f4")
                   }*/
               },
               new LanguageViewModel{
                LanguageId = new Guid("79d823b3-48d2-4199-85dd-e83d4449bf80"),
                LanguageName = "English",
                /*BookId = new List<Guid>()
                {
                    new Guid("b4d916c4-9094-4fd8-9962-2740156cb8f4"),
                    new Guid("d983427c-9b76-4189-9148-ad59ffcfa2c2")
                }*/
               },
               new LanguageViewModel{
                LanguageId = new Guid("76792759-d565-4ef2-b438-5d6d3523d812"),
                LanguageName = "French",
              /*  BookId =
                   new List<Guid>{
                   new Guid("d983427c-9b76-4189-9148-ad59ffcfa2c2")
                   }*/
               }
    };

        /// <summary>
        /// The authors
        /// </summary>
        private readonly List<AuthorViewModel> _authors =
        new()
    {
               new AuthorViewModel{
                AuthorId = new Guid("899d3f2b-5c2a-4970-acee-40637fef3f29"),
                Name = "Porcha",
                Nationality = "Chinese",
                Country = "TH",
                //BookId = new Guid("b4d916c4-9094-4fd8-9962-2740156cb8f4")
               },
               new AuthorViewModel{
                AuthorId = new Guid("fc87a061-eee3-4111-9bc4-a9a856114471"),
                Name = "Chapor",
                Nationality ="Thai",
                Country = "US",
               //BookId = new Guid("f1cee11d-ac16-4186-a0d8-63b8213c6664"),
               },
               new AuthorViewModel{
                AuthorId = new Guid ("0b8a3959-bfdf-4c09-b2e8-ad478e53610e"),
                Name = "Por",
                Nationality ="Indian",
                Country = "BE",
                //BookId = new Guid("d983427c-9b76-4189-9148-ad59ffcfa2c2"),
               },
    };

        public List<BookViewModel> GetBooks() => _books;

        public List<CountryViewModel> GetCountries() => _countries;

        public List<AuthorViewModel> GetAuthors() => _authors;

        public List<LanguageViewModel> GetLanguages() => _languages;
    }
}