﻿namespace Bookstore.Core.Error
{
    public class GraphQlErrorFilter : IErrorFilter
    {
        public IError OnError(IError error)
        {
            if (error.Exception is InvalidOperationException)
            {
                InvalidOperationException ex = error.Exception as InvalidOperationException;
                return error.WithMessage(ex.Message);
            }
            if (error.Exception is NullReferenceException)
            {
                NullReferenceException ex = error.Exception as NullReferenceException;
                return error.WithMessage(ex.Message);
            }
            if (error.Exception is NotSupportedException)
            {
                NotSupportedException ex = error.Exception as NotSupportedException;
                return error.WithMessage(ex.Message);
            }
            return error.WithCode("INTERNAL_SERVER_ERROR").WithMessage(error.Exception.Message);
        }
    }
}