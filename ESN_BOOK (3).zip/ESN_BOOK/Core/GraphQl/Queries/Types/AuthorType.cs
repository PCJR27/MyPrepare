﻿using Bookstore.Core.Models.View;
using Bookstore.Core.Services;

namespace Bookstore.Core.GraphQl.Queries.Types
{
    /// <summary>
    ///  class it tell structure to hot chocolate
    /// </summary>
    /// <seealso cref="ObjectType&lt;AuthorViewModel&gt;" />
    public class AuthorType : ObjectType<AuthorViewModel>
    {
        /// <summary>
        /// Override this to configure the type.
        /// </summary>
        /// <param name="descriptor">The descriptor allows to configure the interface type.</param>
        protected override void Configure(IObjectTypeDescriptor<AuthorViewModel> descriptor)
        {
            descriptor.Name("Author");
            descriptor.Field("id").Type<IdType>().Resolve(context => context.Parent<AuthorViewModel>().AuthorId);
            //descriptor.Field(author => author.AuthorId);
            descriptor.Field(author => author.Name);
            descriptor.Field(author => author.Nationality);
            descriptor.Field(author => author.Country).Description("Country of Author")
                .Type<CountryType>()
                .Resolve(context => context.Service<CountriesService>().GetCountryForAuthor(context.Parent<AuthorViewModel>().Country));
        }
    }
}