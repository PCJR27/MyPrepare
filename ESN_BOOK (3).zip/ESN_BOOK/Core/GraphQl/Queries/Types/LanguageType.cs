﻿using Bookstore.Core.Models.View;

namespace Bookstore.Core.GraphQl.Queries.Types
{
    /// <summary>
    /// class it tell structure to hot chocolate
    /// </summary>
    /// <seealso cref="ObjectType&lt;LanguageViewModel&gt;" />
    public class LanguageType : ObjectType<LanguageViewModel>
    {
        /// <summary>
        /// Override this to configure the type.
        /// </summary>
        /// <param name="descriptor">The descriptor allows to configure the interface type.</param>
        protected override void Configure(IObjectTypeDescriptor<LanguageViewModel> descriptor)
        {
            descriptor.Name("Language");
            descriptor.Field("id").Type<IdType>()
                .Resolve(context => context.Parent<LanguageViewModel>().LanguageId);
            //descriptor.Field(l => l.LanguageId);
            descriptor.Field("name").Type<StringType>().Resolve(context => context.Parent<LanguageViewModel>().LanguageName);
            //descriptor.Field(l => l.LanguageName);
        }
    }
}