﻿namespace Bookstore.Core.Models.Input
{
    /// <summary>
    /// Structure Input Book for Update
    /// </summary>
    public class BookUpdateModel
    {
        public string Title { get; set; }
        public List<Guid> Language { get; set; }
        public int? Price { get; set; }
        public string Country { get; set; }
        public string IsbnCode { get; set; }
    }
}