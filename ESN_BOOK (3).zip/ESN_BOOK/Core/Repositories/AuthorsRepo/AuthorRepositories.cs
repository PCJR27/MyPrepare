﻿using Bookstore.Core.DBContext;
using Bookstore.Core.Models.View;

namespace Bookstore.Core.Repositories.AuthorsRepo
{
    /// <summary>
    /// Store actions performed with Author information
    /// </summary>
    /// <seealso cref="Bookstore.Core.Repositories.AuthorsRepo.IAuthorRepositories&lt;AuthorViewModel&gt;" />
    public class AuthorRepositories : IAuthorRepositories
    {
        /// <summary>
        /// The data context
        /// </summary>
        private readonly DataBaseContext _dataContext;

        /// <summary>
        /// Initializes a new instance of the <see cref="AuthorRepositories"/> class.
        /// </summary>
        /// <param name="dataContext">The data context.</param>
        /// <exception cref="System.ArgumentNullException">dataContext</exception>
        public AuthorRepositories(DataBaseContext dataContext) =>
        _dataContext = dataContext ?? throw new ArgumentNullException(nameof(dataContext));

        /// <summary>
        /// Gets all.
        /// </summary>
        /// <returns></returns>
        public List<AuthorViewModel> GetAll() => _dataContext.GetAuthors();

        /// <summary>
        /// Gets the by book identifier.
        /// </summary>
        /// <param name="bookData">The book data.</param>
        /// <returns></returns>
        public AuthorViewModel GetByBookId(Guid bookData) =>
         _dataContext.GetAuthors()
         .Find(author => author.AuthorId == bookData);

        public AuthorViewModel GetById(Guid id) =>
         _dataContext.GetAuthors().Find(author => author.AuthorId == id);

        //public bool CheckExists(Guid authorId) =>
        //_dataContext.GetAuthors().Any(author => author.AuthorId == authorId);
    }
}