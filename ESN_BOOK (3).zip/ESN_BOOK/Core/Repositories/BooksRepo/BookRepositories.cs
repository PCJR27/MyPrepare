﻿using Bookstore.Core.DBContext;
using Bookstore.Core.Models.Input;
using Bookstore.Core.Models.View;

namespace Bookstore.Core.Repositories.BooksRepo
{
    /// <summary>
    /// Store actions performed with Book information
    /// </summary>
    /// <seealso cref="Bookstore.Core.Repositories.BooksRepo.IBookRepositories&lt;BookViewModel&gt;" />
    public class BookRepositories : IBookRepositories
    {
        /// <summary>
        /// The author context
        /// </summary>
        private readonly DataBaseContext _dataContext;

        /// <summary>
        /// Initializes a new instance of the <see cref="AuthorRepositories"/> class.
        /// </summary>
        /// <param name="authorContext">The author context.</param>
        /// <exception cref="System.ArgumentNullException">authorContext</exception>
        public BookRepositories(DataBaseContext dataContext) =>
        _dataContext = dataContext ?? throw new ArgumentNullException(nameof(dataContext));

        /// <summary>
        /// Adds the specified book.
        /// </summary>
        /// <param name="book">The book.</param>
        /// <returns></returns>
        public BookViewModel Add(BookViewModel book)
        {
            _dataContext.GetBooks().Add(book);
            return book;
        }

        /// <summary>
        /// Deletes the specified identifier.
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <returns></returns>
        /// <exception cref="InvalidOperationException">Book with ID {id} not found.</exception>
        public bool Delete(BookViewModel bookDelete)
        {
            return _dataContext.GetBooks().Remove(bookDelete); ;
        }

        /// <summary>
        /// Gets all.
        /// </summary>
        /// <returns></returns>
        public List<BookViewModel> GetAll() => _dataContext.GetBooks();

        /// <summary>
        /// Gets the book by title.
        /// </summary>
        /// <param name="titles">The titles.</param>
        /// <returns></returns>
        public List<BookViewModel> GetBookByTitle(List<string> titles)
        {
            List<BookViewModel> listBook = new();
            listBook = _dataContext.GetBooks()
            .Where(book => titles.Any(title =>
            !title.Trim().Equals("") &&
             book.Title.ToLower()
            .Contains(title.Trim().ToLower())))
            .ToList();

            return listBook;
        }

        /// <summary>
        /// Gets the by identifier.
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <returns></returns>
        public BookViewModel GetById(Guid id)
        {
            return _dataContext.GetBooks().Find(b => b.BookId == id);
        }

        /// <summary>
        /// Updates the specified identifier.
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <param name="editBook">The edit book.</param>
        /// <returns></returns>
        /// <exception cref="InvalidOperationException">Book with ID {id} not found.</exception>
        public BookViewModel Update(int indexBook, BookViewModel editBook)
        {
            _dataContext.GetBooks()[indexBook].Title = editBook.Title;
            _dataContext.GetBooks()[indexBook].Languages = editBook.Languages;
            _dataContext.GetBooks()[indexBook].Price = editBook.Price;
            _dataContext.GetBooks()[indexBook].Country = editBook.Country;
            _dataContext.GetBooks()[indexBook].IsbnCode = editBook.IsbnCode;
            return _dataContext.GetBooks()[indexBook];
        }

        public int FindIndex(BookViewModel book) =>

            _dataContext.GetBooks().IndexOf(book);
    }
}