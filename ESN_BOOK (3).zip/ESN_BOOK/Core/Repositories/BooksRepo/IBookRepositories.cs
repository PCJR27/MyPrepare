﻿using Bookstore.Core.Models.Input;
using Bookstore.Core.Models.View;

namespace Bookstore.Core.Repositories.BooksRepo
{
    /// <summary>
    /// Template actions performed with Book information
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public interface IBookRepositories
    {
        List<BookViewModel> GetBookByTitle(List<string> titles);

        List<BookViewModel> GetAll();

        BookViewModel Add(BookViewModel book);

        BookViewModel Update(int selectBook, BookViewModel bookEdit);

        bool Delete(BookViewModel bookDelete);

        BookViewModel GetById(Guid id);

        int FindIndex(BookViewModel book);
    }
}