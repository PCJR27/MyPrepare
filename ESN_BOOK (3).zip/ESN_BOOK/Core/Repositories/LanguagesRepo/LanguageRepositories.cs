﻿using Bookstore.Core.DBContext;
using Bookstore.Core.Models.View;

namespace Bookstore.Core.Repositories.LanguagesRepo
{
    /// <summary>
    /// Store actions performed with Language information
    /// </summary>
    /// <seealso cref="Bookstore.Core.Repositories.LanguagesRepo.ILanguageRepositories&lt;LanguageViewModel&gt;" />
    public class LanguageRepositories : ILanguageRepositories
    {
        /// <summary>
        /// The data context
        /// </summary>
        private readonly DataBaseContext _dataContext;

        /// <summary>
        /// Initializes a new instance of the <see cref="LanguageRepositories"/> class.
        /// </summary>
        /// <param name="dataContext">The data context.</param>
        /// <exception cref="System.ArgumentNullException">dataContext</exception>
        public LanguageRepositories(DataBaseContext dataContext) =>
        _dataContext = dataContext ?? throw new ArgumentNullException(nameof(dataContext));

        public LanguageViewModel GetLanguageById(Guid id) =>
       _dataContext.GetLanguages().Find(language => language.LanguageId == id);

        /// <summary>
        /// Gets the by identifier.
        /// </summary>
        /// <param name="bookDataLanguage">The book data language.</param>
        /// <returns></returns>
        public List<LanguageViewModel> GetLanguageByIdFromBook(List<Guid> bookDataLanguage) =>

            _dataContext.GetLanguages().Where(languageList => bookDataLanguage
                    .Contains(languageList.LanguageId))
                    .ToList();

        public List<LanguageViewModel> GetLanguages() => _dataContext.GetLanguages();
    }
}