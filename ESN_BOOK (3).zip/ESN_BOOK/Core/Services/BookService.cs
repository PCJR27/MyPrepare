﻿using Bookstore.Core.DBContext;
using Bookstore.Core.Models.Input;
using Bookstore.Core.Models.View;
using Bookstore.Core.Repositories.AuthorsRepo;
using Bookstore.Core.Repositories.BooksRepo;
using Bookstore.Core.Repositories.CountriesRepo;
using Bookstore.Core.Repositories.LanguagesRepo;

namespace Bookstore.Core.Services
{
    /// <summary>
    ///  it provide book can do and can easy to use it because it provide what you want to use when call book Structure
    /// </summary>
    public class BookService
    {
        /// <summary>
        /// The book repositories
        /// </summary>
        private readonly BookRepositories _bookRepositories;

        private readonly AuthorService _authorService;

        private readonly CountriesRepositories _countryRepositories;
        private readonly LanguageService _languageService;

        /// <summary>
        /// Initializes a new instance of the <see cref="BookService"/> class.
        /// </summary>
        /// <param name="bookRepo">The book repo.</param>
        /// <exception cref="ArgumentNullException">bookRepo</exception>
        public BookService(BookRepositories bookRepo, AuthorService authorService, CountriesRepositories countriesRepo, LanguageService languageService)
        {
            _bookRepositories = bookRepo ?? throw new ArgumentNullException(nameof(bookRepo));
            _authorService = authorService ?? throw new ArgumentNullException(nameof(authorService));
            _countryRepositories = countriesRepo ?? throw new ArgumentNullException(nameof(countriesRepo));
            _languageService = languageService ?? throw new ArgumentNullException(nameof(languageService));
        }

        /// <summary>
        /// Gets the books.
        /// </summary>
        /// <param name="titles">The titles.</param>
        /// <returns></returns>
        public List<BookViewModel> GetBooksOrFilterByTitle(List<string> titles)
        {
            if (titles != null && titles.Any())
            {
                return _bookRepositories.GetBookByTitle(titles);
            }

            return _bookRepositories.GetAll();
        }

        /// <summary>
        /// Gets the one book.
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <returns></returns>
        public BookViewModel GetOneBook(Guid id) =>
            _bookRepositories.GetById(id);

        /// <summary>
        /// Adds the new book.
        /// </summary>
        /// <param name="book">The book.</param>
        /// <returns></returns>
        public BookViewModel AddNewBook(BookCreateModel book)
        {
            _authorService.CheckExists(book.Author);
            _languageService.CheckExists(book.Language);

            var newBook = new BookViewModel
            {
                BookId = Guid.NewGuid(),
                Title = book.Title,
                Author = book.Author,
                Languages = book.Language,
                Country = book.Country ?? null,
                IsbnCode = book.IsbnCode ?? null,
                Price = book.Price ?? null
            };
            return _bookRepositories.Add(newBook);
        }

        /// <summary>
        /// Updates the book.
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <param name="editBook">The edit book.</param>
        /// <returns></returns>
        /// <exception cref="InvalidOperationException">Book with ID {id} not found.</exception>
        public BookViewModel UpdateBook(Guid id, BookUpdateModel editBook)
        {
            BookViewModel selectedBook = GetOneBook(id);
            if (selectedBook != null)
            {
               int numberIndex = _bookRepositories.FindIndex(selectedBook);
                _languageService.CheckExists(editBook.Language);
                
                selectedBook.Title = editBook.Title ?? selectedBook.Title;
                selectedBook.Languages = editBook.Language ?? selectedBook.Languages;
                selectedBook.Price = editBook.Price ?? selectedBook.Price;
                selectedBook.Country = editBook.Country ?? selectedBook.Country;
                selectedBook.IsbnCode = editBook.IsbnCode ?? selectedBook.IsbnCode;
                selectedBook.Author = selectedBook.Author;
                return _bookRepositories.Update(numberIndex, selectedBook);
            }
            else
            {
                throw new InvalidOperationException($"Book with ID {id} not found.");
            }
        }

        /// <summary>
        /// Deletes the book.
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <returns></returns>
        /// <exception cref="InvalidOperationException">Book with ID {id} not found.</exception>
        public bool DeleteBook(Guid id)
        {
            BookViewModel bookDelete = GetOneBook(id) ??
            throw new InvalidOperationException($"Book with ID {id} not found.");
            return _bookRepositories.Delete(bookDelete);
        }

        public void CheckExists(Guid bookId)
        {
            if (!_bookRepositories.GetAll().Any(book => book.BookId == bookId))
            {
                throw new NullReferenceException($"Cannot Add Because AuthorId : {bookId} not found");
            }
        }
    }
}