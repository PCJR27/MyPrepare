﻿using Bookstore.Core.GraphQl.Mutations.Types.InputType;
using Bookstore.Core.GraphQl.Queries.Types;
using Bookstore.Core.Models.Input;
using Bookstore.Core.Services;

namespace Bookstore.Core.GraphQl.Mutations
{
    /// <summary>
    /// Mutation Books
    /// </summary>
    /// <seealso cref="ObjectType" />
    public class MutationType : ObjectType
    {
        /// <summary>
        /// Override this to configure the type.
        /// </summary>
        /// <param name="descriptor">The descriptor allows to configure the interface type.</param>
        protected override void Configure(
         IObjectTypeDescriptor descriptor)
        {
            descriptor.Field("addBook")
                    .Argument("newBook", newBook => newBook.Type<NonNullType<BookInputType>>())
                    .Type<BookType>()
                    .Resolve(context =>
                           context.Service<BookService>().AddNewBook(context.ArgumentValue<BookCreateModel>("newBook"))
                    );
            descriptor.Field("updateBook")
                .Argument("editBook", editBook => editBook.Type<NonNullType<BookInputUpdateType>>())
                .Argument("idBook", idBook => idBook.Type<NonNullType<IdType>>())
                .Type<BookType>()
                .Resolve(context => context.Service<BookService>().UpdateBook(context.ArgumentValue<Guid>("idBook"),
                context.ArgumentValue<BookUpdateModel>("editBook")));

            descriptor.Field("deleteBook")
                .Argument("deleteId", deleteId => deleteId.Type<NonNullType<IdType>>())
                .Type<BooleanType>()
                .Resolve(context => context.Service<BookService>().DeleteBook(context.ArgumentValue<Guid>("deleteId")));
        }
    }
}