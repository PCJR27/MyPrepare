﻿using Bookstore.Core.Models;

namespace Bookstore.Core.GraphQl.Queries.Types
{
    /// <summary>
    /// class it tell structure to hot chocolate
    /// </summary>
    /// <seealso cref="ObjectType&lt;CountryViewModel&gt;" />
    public class CountryType : ObjectType<CountryModel>
    {
        /// <summary>
        /// Override this to configure the type.
        /// </summary>
        /// <param name="descriptor">The descriptor allows to configure the interface type.</param>
        protected override void Configure(IObjectTypeDescriptor<CountryModel> descriptor)
        {
            descriptor.Name("Country");
            descriptor.Field("code").Type<StringType>()
                .Resolve(context => context.Parent<CountryModel>().CountryId);
            //descriptor.Field(country => country.Code);
            descriptor.Field(country => country.Name);
        }
    }
}