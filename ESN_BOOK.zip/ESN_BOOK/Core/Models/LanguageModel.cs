﻿namespace Bookstore.Core.Models
{
    /// <summary>
    /// Structure of Language
    /// </summary>
    public class LanguageModel
    {
        /// <summary>
        /// Gets or sets the language identifier.
        /// </summary>
        /// <value>
        /// The language identifier.
        /// </value>
        public Guid LanguageId { get; set; }

        /// <summary>
        /// Gets or sets the name of the language.
        /// </summary>
        /// <value>
        /// The name of the language.
        /// </value>
        public string LanguageName { get; set; }
    }
}