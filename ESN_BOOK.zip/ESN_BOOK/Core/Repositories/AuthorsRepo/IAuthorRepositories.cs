﻿using Bookstore.Core.Models;

namespace Bookstore.Core.Repositories.AuthorsRepo
{
    /// <summary>
    /// Template actions performed with Author information
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public interface IAuthorRepositories
    {
        List<AuthorModel> GetAll();

        AuthorModel GetByBookId(Guid id);

        AuthorModel GetById(Guid id);
    }
}