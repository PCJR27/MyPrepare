﻿using Bookstore.Core.Models;
using Bookstore.Core.Models.Input;

namespace Bookstore.Core.Repositories.BooksRepo
{
    /// <summary>
    /// Template actions performed with Book information
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public interface IBookRepositories
    {
        List<BookModel> GetBookByTitle(List<string> titles);

        List<BookModel> GetAll();

        BookModel Add(BookModel book);

        BookModel Update(int selectBook, BookModel bookEdit);

        bool Delete(BookModel bookDelete);

        BookModel GetById(Guid id);

        int FindIndex(BookModel book);
    }
}