﻿using Bookstore.Core.DBContext;
using Bookstore.Core.Models;

namespace Bookstore.Core.Repositories.CountriesRepo
{
    /// <summary>
    /// Store actions performed with Country information
    /// </summary>
    /// <seealso cref="Bookstore.Core.Repositories.CountriesRepo.ICountriesRepositories&lt;CountryViewModel&gt;" />
    public class CountriesRepositories : ICountriesRepositories
    {
        /// <summary>
        /// The data context
        /// </summary>
        private readonly DataBaseContext _dataContext;

        /// <summary>
        /// Initializes a new instance of the <see cref="CountriesRepositories"/> class.
        /// </summary>
        /// <param name="dataContext">The data context.</param>
        /// <exception cref="System.ArgumentNullException">dataContext</exception>
        public CountriesRepositories(DataBaseContext dataContext) =>
        _dataContext = dataContext ?? throw new ArgumentNullException(nameof(dataContext));

        /// <summary>
        /// Gets the by identifier.
        /// </summary>
        /// <param name="data">The data.</param>
        /// <returns></returns>
        public CountryModel GetById(string data) =>
            _dataContext.GetCountries().Find(country => country.CountryId == data);

        public bool CheckExists(string countryId) =>
       _dataContext.GetCountries().Any(country => country.CountryId == countryId);
    }
}