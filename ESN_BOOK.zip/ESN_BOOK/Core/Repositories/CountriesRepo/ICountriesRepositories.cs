﻿using Bookstore.Core.Models;

namespace Bookstore.Core.Repositories.CountriesRepo
{
    /// <summary>
    /// Template actions performed with Country information
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public interface ICountriesRepositories
    {
        CountryModel GetById(string data);
        bool CheckExists(string id);
    }
}