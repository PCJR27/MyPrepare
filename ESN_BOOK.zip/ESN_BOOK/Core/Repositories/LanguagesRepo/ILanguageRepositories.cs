﻿using Bookstore.Core.Models;

namespace Bookstore.Core.Repositories.LanguagesRepo
{
    /// <summary>
    /// Template actions performed with Language information
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public interface ILanguageRepositories
    {
        List<LanguageModel> GetLanguageByIdFromBook(List<Guid> id);

        List<LanguageModel> GetLanguages();

        LanguageModel GetLanguageById(Guid id);
    }
}