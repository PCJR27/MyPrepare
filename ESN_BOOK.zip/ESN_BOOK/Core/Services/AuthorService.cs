﻿using Bookstore.Core.DBContext;
using Bookstore.Core.Models;
using Bookstore.Core.Repositories.AuthorsRepo;

namespace Bookstore.Core.Services
{
    /// <summary>
    /// it provide author can do and can easy to use it because it provide what you want to use when call Author Structure
    /// </summary>
    public class AuthorService
    {
        /// <summary>
        /// The author repositories
        /// </summary>
        private readonly AuthorRepositories _authorRepositories;

        /// <summary>
        /// Initializes a new instance of the <see cref="AuthorService"/> class.
        /// </summary>
        /// <param name="authorRepositories">The author repositories.</param>
        /// <exception cref="ArgumentNullException">authorRepositories</exception>
        public AuthorService(AuthorRepositories authorRepositories)
        {
            _authorRepositories = authorRepositories ?? throw new ArgumentNullException(nameof(authorRepositories));
        }

        /// <summary>
        /// Gets the author.
        /// </summary>
        /// <param name="bookData">The book data.</param>
        /// <returns></returns>
        public AuthorModel GetAuthor(Guid bookData) =>
        _authorRepositories.GetByBookId(bookData);

        /// <summary>
        /// Gets the authors.
        /// </summary>
        /// <returns></returns>
        public List<AuthorModel> GetAuthors() =>
         _authorRepositories.GetAll();

        public void CheckExists(Guid authorId)
        {
            if (!_authorRepositories.GetAll().Any(author => author.AuthorId == authorId))
            {
                throw new NullReferenceException($"Cannot Add Because AuthorId : {authorId} not found");
            }
        }
    }
}