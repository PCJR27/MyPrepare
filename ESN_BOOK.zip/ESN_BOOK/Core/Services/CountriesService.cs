﻿using Bookstore.Core.DBContext;
using Bookstore.Core.Models;
using Bookstore.Core.Repositories.CountriesRepo;

namespace Bookstore.Core.Services
{
    /// <summary>
    /// it provide country can do and can easy to use it because it provide what you want to use when call country Structure
    /// </summary>
    public class CountriesService
    {
        /// <summary>
        /// The countries repositories
        /// </summary>
        private readonly CountriesRepositories _countriesRepositories;

        /// <summary>
        /// Initializes a new instance of the <see cref="CountriesService"/> class.
        /// </summary>
        /// <param name="countriesRepo">The countries repo.</param>
        /// <exception cref="ArgumentNullException">countriesRepo</exception>
        public CountriesService(CountriesRepositories countriesRepo)
        {
            _countriesRepositories = countriesRepo ?? throw new ArgumentNullException(nameof(countriesRepo));
        }

        /// <summary>
        /// Gets the country for book.
        /// </summary>
        /// <param name="bookData">The book data.</param>
        /// <returns></returns>
        public CountryModel GetCountryForBook(string bookData) =>
          _countriesRepositories.GetById(bookData);

        /// <summary>
        /// Gets the country for author.
        /// </summary>
        /// <param name="authorData">The author data.</param>
        /// <returns></returns>
        public CountryModel GetCountryForAuthor(string authorData) =>
            _countriesRepositories.GetById(authorData);
    }
}