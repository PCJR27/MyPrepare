using Bookstore.Queries;
using Bookstore.Services;

var builder = WebApplication.CreateBuilder(args);
builder.Services
    .AddGraphQLServer()
    .AddQueryType<QueryType>();
builder.Services.AddTransient<BookService>();
var app = builder.Build();
app.MapGraphQL("/");
//app.MapGet("/", () => "Hello World!");

app.Run();
