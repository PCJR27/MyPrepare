﻿using Bookstore.Services;

namespace Bookstore.Queries
{
    public class QueryType :ObjectType
    {
        protected override void Configure(IObjectTypeDescriptor descriptor)
        {
            descriptor.Field("books")
             .Description("Get all books")
             .Argument("titles", a => a.Type<ListType<StringType>>())
             .Type<ListType<BookType>>()
             .Resolve(context =>
             {
                 var titles = context.ArgumentValue<List<string>>("titles");
                 Console.WriteLine(titles);
                if(titles != null && titles.Any()) {
                     return context.Service<BookService>().GetBookByTitle(titles);
                 }
                return context.Service<BookService>().GetBooks();
             });
            descriptor.Field("book")
      .Description("Get a book")
      .Argument("id", a => a.Type<IdType>())
      .Type<BookType>()
      .Resolve(context => context.Service<BookService>().GetOneBook(context.ArgumentValue<Guid>("id")));

            descriptor.Field("author").Description("Get All Author")
                    .Type<ListType<AuthorType>>()
                    .Resolve(context => context.Service<BookService>().GetAuthors());

        }
    }
}
