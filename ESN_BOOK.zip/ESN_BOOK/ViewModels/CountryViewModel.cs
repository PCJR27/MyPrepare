﻿namespace Bookstore.ViewModels
{
    public class CountryViewModel
    {
        public string code { get; set; }
        public string name { get; set; }
        public Guid book_id { get; set; }
        public Guid author_id { get; set; }
    }
}
