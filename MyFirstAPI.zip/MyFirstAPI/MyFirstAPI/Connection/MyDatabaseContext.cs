﻿using Microsoft.EntityFrameworkCore;
using MyFirstAPI.Model;

namespace MyFirstAPI.Connection
{
    public class MyDatabaseContext:DbContext
    {
        public MyDatabaseContext(DbContextOptions<MyDatabaseContext> options) :base(options)
        {
            
        }
        public DbSet<Actor> actor { get; set; }
        public DbSet<Film> film { get; set; }
        public DbSet<Film_Actor> film_actor { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Film_Actor>()
                    .HasKey(pc => new { pc.actor_id, pc.film_id });
            modelBuilder.Entity<Film_Actor>()
                    .HasOne(p => p.Actor)
                    .WithMany(pc => pc.film_actor)
                    .HasForeignKey(p => p.actor_id);
            modelBuilder.Entity<Film_Actor>()
                    .HasOne(p => p.Film)
                    .WithMany(pc => pc.film_actor)
                    .HasForeignKey(c => c.film_id);
        }
        }
}
