﻿using MyFirstAPI.Model;

namespace MyFirstAPI.DTO
{
    public class filmActorDTO
    {
        public int actor_id { get; set; }
        public int film_id { get; set; }
        public List<Film> Film { get; set; }
        public List<Actor> Actor { get; set; }
        public DateTime last_update { get; set; }
    }
}
