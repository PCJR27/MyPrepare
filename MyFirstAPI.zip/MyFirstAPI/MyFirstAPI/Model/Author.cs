﻿namespace MyFirstAPI.Model
{
    public class Author
    {
        public string Name { get; set; }
    }
}
