﻿namespace MyFirstAPI.Model
{
    public class Book
    {
        public string Title { get; set; }

        public Author Author { get; set; }
    }
}
