﻿using System.ComponentModel.DataAnnotations;

namespace MyFirstAPI.Model
{
    public class Film
    {
        [Key]
        public int film_id { get; set; }
       
        public string title { get; set; }
      
        public string description { get; set; }
     
        public int release_year { get; set; }
      
        public int language_id { get; set; }
 
        public int rental_duration { get; set; }
        
        public int rental_rate { get; set; }
       
        public int length { get; set; }
    
        public int replacement_cost { get; set; }
       
        public string rating { get; set; }
      
        public DateTime last_update { get; set; }
   
        public string special_features { get; set; }
       
        public string fulltext { get; set; }
        public ICollection<Film_Actor>? film_actor { get; set; }
    }
}
