﻿namespace MyFirstAPI.Model
{
    public class Film_Actor
    {
        public int actor_id { get; set; }
        public int film_id { get; set; }
        public Film Film { get; set; }
        public Actor Actor { get; set; }
        public DateTime last_update { get; set; }
    }
}
