﻿namespace MyFirstAPI.Service
{
    public interface ISingleton
    {
        public int getCount();
    }
}
