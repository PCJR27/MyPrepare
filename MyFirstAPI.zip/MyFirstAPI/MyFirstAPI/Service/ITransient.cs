﻿namespace MyFirstAPI.Service
{
    public interface ITransient 
    {
        public int getCount();
    }
}
