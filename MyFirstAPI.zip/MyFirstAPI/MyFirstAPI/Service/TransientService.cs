﻿namespace MyFirstAPI.Service
{
    public class TransientService :ITransient
    {
        public TransientService()
        {
            
        }
        public int Count;
        // ใช้งาน function จาก Interface
        public int getCount()
        {
            return Count = Count + 1;
        }
    }
}
