﻿using MyFirstAPI.Connection;
using MyFirstAPI.Model;
using MyFirstAPI.Service;
using System.Runtime.Intrinsics.X86;

namespace MyFirstAPI.graphql
{
    public class Query
    {
        public Query()
        {

        }
        public int PorchaMethod([Service] SingletonService service)

        {
            return service.getCount();
        }
        public int Second([Service] TransientService tService)
        {
            return tService.getCount();
        }

        public IQueryable<Actor> getActor([Service] MyDatabaseContext context)
        {
            return context.actor;
        }
        public Actor getByActorId([Service] MyDatabaseContext context, int id)
        {
            return context.actor.Where(e => e.actor_id == id).FirstOrDefault();
        }
        public Actor GetActorByIdFromFilmActor([Service] MyDatabaseContext context, int actorId)
        {
            var actor = context.film_actor
                .Where(fa => fa.actor_id == actorId)
                .Select(fa => fa.Actor)
                .FirstOrDefault();

            return actor;
        }
    }
}