﻿// See https://aka.ms/new-console-template for more information

using MyLibrary;

int total = 1000;
decimal sum = 1000.0M;
string text = "MyText";
bool isTrue = true;

var myVar = "MyStringVariable";

MyClass myClass = new();

int aNumber = myClass.DoubleNumber(25);

Func<int, int> myDoubleMethod = myClass.DoubleNumber;
Func<int, int, int> mySumMethod = myClass.SumNumbers;

Action<int> myPrintMethod = myClass.PrintNumber;

int anotherNumber = myDoubleMethod(5);

int result = myClass.ReturnCachedOrExectute(
    "dummy",
    input => input * input);

Console.WriteLine($"Hello, {anotherNumber}!");