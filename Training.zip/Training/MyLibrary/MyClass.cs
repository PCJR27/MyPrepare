﻿namespace MyLibrary
{
    public class MyClass
    {
        private Dictionary<string, int> _myCache = new();

        public int GiveNumber()
        {
            return 30;
        }

        public int GiveAnotherNumber() => 25;

        public int DoubleNumber(int number) => number * 2;

        public int SumNumbers(int number1, int number2) => number1 + number2;

        public void PrintNumber(int number)
        {
            Console.WriteLine(number);
        }

        public int ReturnCachedOrExectute(
            string key,
            Func<int, int> resultSelector
            )
        {
            int input = 0;

            if (_myCache.ContainsKey(key))
            {
                input = _myCache[key];
            }

            int result = resultSelector(input);

            _myCache.Add(key, result);

            return result;
        }

        public int MakeTotalFor(List<Price> prices)
        {
            int total = 0;

            for (int i = 0; i < prices.Count; i++)
            {
                total += prices[i].Amount;
            }

            return total;
        }

        public int MakeTotalForEach(List<Price> prices)
        {
            int total = 0;

            foreach (Price price in prices)
            {
                total += price.Amount;
            }

            return total;
        }

        public int MakeTotalAmountLinq(List<Price> prices)
        {
            return prices.Sum(price => price.Amount);
        }

        public class Price
        {
            public int Amount { get; set; }
            public string Currency { get; set; }
        }
    }
}