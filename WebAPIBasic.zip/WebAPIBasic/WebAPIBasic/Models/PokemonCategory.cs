﻿namespace WebAPIBasic.Models
{
    public class PokemonCategory
    {
        public int PokemonId { get; set; }
        public int CategoryId { get; set; }
        //many to many
        public Pokemon Pokemon { get; set; }
        public Category Category { get; set; }
    }
}
