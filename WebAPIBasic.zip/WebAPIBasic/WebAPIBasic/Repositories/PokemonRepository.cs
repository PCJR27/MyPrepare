﻿using WebAPIBasic.Data;
using WebAPIBasic.interfaces;
using WebAPIBasic.Models;

namespace WebAPIBasic.Repositories
{
    public class PokemonRepository :IPokemonRepository
    {
        private readonly DataContext _context;
        public PokemonRepository(DataContext context)
        {
            _context = context;
        }
        public ICollection<Pokemon> GetPokemons()
        {
            Console.WriteLine(_context.Pokemon.OrderBy(p => p.Id).ToList());
            return _context.Pokemon.OrderBy(p => p.Id).ToList();
        }
    }
}
