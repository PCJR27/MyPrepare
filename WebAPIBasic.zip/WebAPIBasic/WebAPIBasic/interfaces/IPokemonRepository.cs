﻿using WebAPIBasic.Models;

namespace WebAPIBasic.interfaces
{
    public interface IPokemonRepository
    {
        ICollection<Pokemon> GetPokemons();
    }
}
